import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Arrays;

public class App extends Application {
    int port = 5000;
    String ip = "127.0.0.1";
    BooleanProperty isConnected;
    SocketChannel socket;
    Button connect, disconnect, send;
    TextArea msgBox;
    ObservableList<String> messages;
    ListView inBox;

    @Override
    public void start(Stage stage) throws Exception {
        isConnected = new SimpleBooleanProperty();
        isConnected.set(false);
        connect = new Button("Conntect");
        disconnect = new Button("Disconnect");
        connect.disableProperty().bind(isConnected);
        disconnect.disableProperty().bind(isConnected.not());
        connect.setOnMouseClicked(this::connect);
        disconnect.setOnMouseClicked(this::disconnect);
        var box = new VBox(connect, disconnect);
        box.setSpacing(10);

        messages = FXCollections.observableArrayList();
        msgBox = new TextArea();
        inBox = new ListView();
        inBox.setItems(messages);
        send = new Button("Send");
        send.setOnMouseClicked(this::send);
        var cBox = new VBox(inBox, msgBox, send);
        VBox.setVgrow(inBox, Priority.ALWAYS);
        VBox.setVgrow(msgBox, Priority.ALWAYS);
        var border = new BorderPane();
        border.setLeft(box);
        border.setCenter(cBox);
        var scene = new Scene(border, 300,300);
        stage.setScene(scene);
        stage.setTitle("Client");
        stage.show();
    }
    void connect(MouseEvent e) {
        try {
            socket = SocketChannel.open();
            socket.connect(new InetSocketAddress(ip, port));
            isConnected.set(true);
            read();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    void read() {
        var thread = new Thread(() ->{
            var buff = ByteBuffer.allocate(1024);
           while (isConnected.get()){
               try {
                   int read = socket.read(buff);
                   Platform.runLater(() ->{
                       messages.add(new String(Arrays.copyOfRange(buff.array(), 0, read)));
                       buff.clear();
                   });
               } catch (IOException e) {
                   isConnected.set(false);
               }
           }
            System.out.println("Client reading thread closing");
        });
        thread.start();
    }

    void disconnect(MouseEvent e) {
        try {
            isConnected.set(false);
            socket.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    void send(MouseEvent e)  {
        try {
            socket.write(ByteBuffer.wrap(msgBox.getText().getBytes()));
            msgBox.setText("");
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void stop() throws Exception {
        super.stop();
        if(socket != null) socket.close();
    }

    static void main(String[] a) { launch(a); }
}
