import javafx.application.Platform;
import javafx.collections.ObservableList;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Arrays;
import java.util.concurrent.ArrayBlockingQueue;

public class ClientHandler extends Thread {
    SocketChannel socket;
    ByteBuffer buffer;
    boolean isConnected;
    ObservableList<SocketChannel> clients;
    ArrayBlockingQueue queue;
    public ClientHandler(SocketChannel socket, ObservableList<SocketChannel> clients, ArrayBlockingQueue<String> queue) {
        this.socket = socket;
        this.clients = clients;
        this.queue = queue;
        buffer = ByteBuffer.allocate(1024);
        isConnected = true;
    }
    @Override
    public void run() {
        while (isConnected){
            try {
                buffer.clear();
                int read = socket.read(buffer);
                var x = Arrays.copyOfRange(buffer.array(), 0, read);
                queue.add(new String(x));

            } catch (IOException e) {
                System.out.println("disconnected");
                isConnected = false;
            }
        }
        System.out.println("getting out");
        Platform.runLater(() -> clients.remove(socket));
    }
}
