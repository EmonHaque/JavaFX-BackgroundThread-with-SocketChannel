import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.concurrent.ArrayBlockingQueue;

public class App extends Application {
    BooleanProperty isListening;
    ServerSocketChannel server;
    Thread listeningThread, broadcastingThread;
    int port = 5000;
    Button start, stop;
    ListView clientList;
    ObservableList<SocketChannel> clients;
    ArrayBlockingQueue<String> queue;

    @Override
    public void start(Stage stage)  {
        queue = new ArrayBlockingQueue<String>(100);
        isListening = new SimpleBooleanProperty();
        isListening.set(false);

        start = new Button("Listen");
        stop = new Button("Stop");
        start.disableProperty().bind(isListening);
        stop.disableProperty().bind(isListening.not());
        start.setOnMouseClicked(this::listen);
        stop.setOnMouseClicked(this::stop);

        var box = new VBox(start, stop);
        box.setSpacing(10);

        clientList = new ListView();
        clients = FXCollections.observableArrayList();
        clientList.setItems(clients);
        var border = new BorderPane();
        border.setLeft(box);
        border.setCenter(clientList);
        var scene = new Scene(border, 300,300);
        stage.setScene(scene);
        stage.setTitle("Server");
        stage.show();
    }
    void broadcast()  {
        while (isListening.get()){
            byte[] msg = new byte[0];
            try {
                String taken = queue.take();
                System.out.println(taken + " taken");
                msg = taken.getBytes();
            } catch (InterruptedException e) {
                //e.printStackTrace();
            }
            for (var client : clients){
                try {
                    client.write(ByteBuffer.wrap(msg));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        System.out.println("broadcasting stopped");
    }
    void listen(MouseEvent e) {
        try {
            server = ServerSocketChannel.open();
            server.bind(new InetSocketAddress(port));
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        isListening.set(true);
        listeningThread = new Thread(() ->{
            while (!listeningThread.isInterrupted()){
                try {
                    var client = server.accept();
                    var handler = new ClientHandler(client, clients, queue);
                    handler.start();
                    Platform.runLater(() ->clients.add(client));

                } catch (IOException ex) {
                    //System.out.println("Interrupted");
                }
            }
            System.out.println("listening stopped");
        });
        listeningThread.start();
        broadcastingThread = new Thread(this::broadcast);
        broadcastingThread.start();
    }
    void stop(MouseEvent e){
        isListening.set(false);
        listeningThread.interrupt();
        broadcastingThread.interrupt();
    }

    @Override
    public void stop() throws Exception {
        super.stop();
        isListening.set(false);
        if(server != null){
            server.close();
            listeningThread.interrupt();
            broadcastingThread.interrupt();
        }
    }

    static void main(String[] a) { launch(a); }
}
